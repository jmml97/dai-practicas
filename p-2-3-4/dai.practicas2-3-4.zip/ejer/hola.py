# ejer/hola.py

print("Hola mundo!")
